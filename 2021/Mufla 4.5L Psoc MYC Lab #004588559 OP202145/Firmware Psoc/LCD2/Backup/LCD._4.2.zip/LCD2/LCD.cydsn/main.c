/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <main.h>

#define OFF 0
#define ON  1

extern uint8 const CYCODE LCD_customFonts[];  
uint8_t i=0,pwm1=128,pwm2=128;
uint16 ctr = 0,Setpoint=0;
uint32_t output=0;
short flagButton0=0,flagButton1=0,flagButton2=0,flagButton3=0;

#define RX_BUFFER_SIZE  10
char Rx_Buffer[RX_BUFFER_SIZE+1];
char Rx_Buffer2[RX_BUFFER_SIZE+1];
char RX_Wr_Index=0;
char RX_Rd_Index=0;
char RX_Counter=0;

#define TX_BUFFER_SIZE  24
char Tx_Buffer[TX_BUFFER_SIZE+1];
char TX_Wr_Index=0;
char TX_Counter=0;
uint8 Dato2=0,Dato_Exitoso=0,Menu=120,MenuAntt=0,z=0,TipoClave=0,Segmentos=0,CicloLibre=0;
short Inicio=0,EstadoPaso=0,entro=0,GuardaEEPROM=0,rampa=OFF,Minutos=OFF,Horas=OFF;
uint8 Password[4]={0,0,0,0};

void CapSense_DisplayState(void);

void SendDataDisplay(void){
CyDelayUs(100);
UART_2_PutChar(0xFF);
CyDelayUs(10);
UART_2_PutChar(0xFF);
CyDelayUs(10);
UART_2_PutChar(0xFF);
CyDelayUs(10);
}

void LeeDisplay(void){
    
    if(Dato_Exitoso==5){
         Rx_Buffer[0]=Rx_Buffer2[0];
         Rx_Buffer[1]=Rx_Buffer2[1];
         Rx_Buffer[2]=Rx_Buffer2[2];
         Rx_Buffer[3]=Rx_Buffer2[3];
         Rx_Buffer[4]=Rx_Buffer2[4];
         Rx_Buffer[5]=Rx_Buffer2[5];
         Rx_Buffer[6]=Rx_Buffer2[6];
         Rx_Buffer[7]=Rx_Buffer2[7];
         Rx_Buffer[8]=Rx_Buffer2[8];
         Rx_Buffer[9]=Rx_Buffer2[9];
         
      if(Rx_Buffer[3]==0x01){// Pregunta por la pagina en la que esta el display,01 es Contraseña de Acceso
         Menu=0;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x02){//02 es Menu Principal con PantallaPriincipal=0, y con PantallaPrincipal=1 es Ciclo Libre
         Menu=1;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x04){//03 es Tiempo Esterilizacion
         Menu=2;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x05){//05 es Temperatura
         Menu=3;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x06){//06 es Nivel
         Menu=5;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x07){//07 es Test de Componentes
         Menu=6;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x08){//08 es Fecha y hora
         Menu=7;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x09){//09 es Rampas
         Menu=8;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x0a){//0a es Pulsos de Vacio
         Menu=9;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x0f){//0f es Recibe caracteres de contraseña desde display
         
      }else if(Rx_Buffer[3]==0x1a){//1a es Menu de Funcionamiento
         Menu=20;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x1b){//1b es Menu de clave correcta
         Menu=15;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x1c){//1c es Menu de clave incorrecta
         Menu=16;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0x2c){//2c es Menu de Configuracion de Parametros
         Menu=100;
         if(MenuAntt!=Menu)
            MenuAntt=Menu;
      }else if(Rx_Buffer[3]==0xcc){//cc es Menu de Bienvenida
         Menu=120;
         //if(MenuAntt!=120)
            //reset_cpu();
      }
   }else{
      for(z=0;z<RX_BUFFER_SIZE;z++){
            //Rx_Buffer[z]=0;
            //Rx_Buffer2[z]=0;
         }
   }
}

CY_ISR(Reloj2){
       VDAC8_1_SetValue(i);
    i++;
    CapSense_DisplayState();
}

CY_ISR(inteRX){
    Dato2=UART_2_GetByte();
   if(Dato2==0x65){//Inicio Comunicacion
      Inicio=1;
      RX_Wr_Index =0;
   }
   if(Inicio==1){
      Rx_Buffer2[RX_Wr_Index] = Dato2;
      RX_Wr_Index++;
   }
   if(RX_Wr_Index >= RX_BUFFER_SIZE){
      RX_Wr_Index =0;
      Inicio=0;
   }
   if(RX_Wr_Index==0){
      if(Rx_Buffer2[0]==0x65 && Rx_Buffer2[1]==0xff && Rx_Buffer2[2]==0xff && Rx_Buffer2[8]==0x00 && Rx_Buffer2[9]==0xff )
         Dato_Exitoso=5;
      else
         Dato_Exitoso=10;
   }
   //if(Menu==20)
//     Buzzer_on;
}

int main(void)
{ 
    CyGlobalIntEnable; /* Enable global interrupts. */
    /* VSSA reference voltage */
    int16 offset;
    
	/* TC cold junction temperature */
    int16 coldJnTemp;
		
	/* cold junction voltage calculated from the cold junction temperature */
    int32 tcColdJnuVolt;
     
    /* TC hot junction ADC count measurement */
    int32 hotJnCount;
    
    /* Filtered hot junction count */
    int32 filHotJnCount;
	
    /* Thermocouple volt calculated from ADC hot Jn count */
    int32 tcHotJnuVolt;
    
    /* Thermocouple voltage measured from tcCount 
     * (cold junction voltage + hot junction voltage) */
    int32 tcuVolt;
    
	/* TC hot junction temperature */
    int32 tcTemp;
    /* LCD display string */
	char displayStr[30] = {'\0'};
	
	/* Flag to indicate whether the program displays a new temperature first time after a Broken TC is detected */
	uint8 first = 0;

    Reloj_StartEx(Reloj2);
    UART_2_Start();
    RX2_StartEx(inteRX);
    LCD_Char_1_Start();  
    Timer_Start();  
    VDAC8_1_Start();
    EEPROM_Start();
        
    ADC_Start();
  
    LCD_Char_1_Position(0u, 0u); // first row, first position  
    LCD_Char_1_PrintString("Dielec Ingenieria DE");  
    
    //ADC_StartConvert();
    //ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
   
    //USBUART_Start(0, USBUART_5V_OPERATION);
    PWM_Start();
    CapSense_Start();
    CapSense_InitializeAllBaselines();    
    LCD_Char_1_Position(3u, 0u); // second row, ninth position  
    LCD_Char_1_PrintString("PWM2:");  
    
    UART_2_PutString("page Bienvenida");
    SendDataDisplay();
    UART_2_PutString("bkcmd=0");
    SendDataDisplay();
    LED_Write(1);
    CyDelay(1500);
    leeEEPROM();
    LED_Write(0);

    for(;;)
    {
        LeeDisplay();
        LCD_Char_1_Position(2u, 0u); // second row, ninth position  
        LCD_Char_1_PrintNumber(flagButton0);
        
        //_--------------------------------------------------------------------------------------------------------------------------------------------------------
        if(Menu == 120){ //Menu de Bienvenida.
            UART_2_PutString("bkcmd=0");
            SendDataDisplay();
            CyDelay(1500);
            UART_2_PutString("page Clave");
            SendDataDisplay();
        }
        //_--------------------------------------------------------------------------------------------------------------------------------------------------------
        
        //_--------------------------------------------------------------------------------------------------------------------------------------------------------
    if(Menu==0){ //Menu de Contraseña de acceso.
      //ApagaSalidas();
      entro=0;
      LED_Write(1);
      if(Rx_Buffer[4]==0x11){//11
         if(TipoClave!=0){
            UART_2_PutString("page Principal");
            SendDataDisplay();
         }
      }
      
      if(TipoClave==3){
         UART_2_PutString("titulo.txt=\"Clave Nueva\"");
         SendDataDisplay();
         UART_2_PutString("doevents");
         SendDataDisplay();
      }else if(TipoClave==2){
         UART_2_PutString("titulo.txt=\"Clave Actual\"");
         SendDataDisplay();
         UART_2_PutString("doevents");
         SendDataDisplay();
      }else if(TipoClave==1 || TipoClave==4){
         UART_2_PutString("titulo.txt=\"Clave Tecnico\"");
         SendDataDisplay();
         UART_2_PutString("doevents");
         SendDataDisplay();
      }else if(TipoClave==0){
         //UART_2_PutString("titulo.txt=\"Ingrese Clave\"");
        sprintf(displayStr,"titulo.txt=\"Ingrese Clave\"");
        UART_2_PutString(displayStr);
        SendDataDisplay();
      }
      
      if(Rx_Buffer[3]==0x0f){//0f, recibe caracteres ingresados desde el Display
         if(TipoClave==0){
            if(Rx_Buffer[4]==0x33&&Rx_Buffer[5]==0x38&&Rx_Buffer[6]==0x39&&Rx_Buffer[7]==0x32){ // Si Ingresa clave para reset general del sistema.
               EEPROM_WriteByte(0,0);CyDelay(20);EEPROM_WriteByte(0,1);CyDelay(20);// Reestablece a contraseña de Fabrica y reinicia Programa.
               EEPROM_WriteByte(0,2);CyDelay(20);EEPROM_WriteByte(0,3);CyDelay(20);
               CySoftwareReset();
            }
            if(Rx_Buffer[4]>=0x30 && Rx_Buffer[5]>=0x30 && Rx_Buffer[6]>=0x30 && Rx_Buffer[7]>=0x30
            && Rx_Buffer[4]<=0x39 && Rx_Buffer[5]<=0x39 && Rx_Buffer[6]<=0x39 && Rx_Buffer[7]<=0x39){
            if((Rx_Buffer[4]==Password[0]+0x30)&&(Rx_Buffer[5]==Password[1]+0x30)&&(Rx_Buffer[6]==Password[2]+0x30)&&(Rx_Buffer[7]==Password[3]+0x30)){
                  UART_2_PutString("page ClaveCorrecta");
                  SendDataDisplay();
                  //RX_Buffer[3]=0x00;RX_Buffer2[3]=0x00;  
               }else{
                  UART_2_PutString("page ClaveBad");
                  SendDataDisplay();
                  //RX_Buffer[3]=0x00;RX_Buffer2[3]=0x00;  
               } 
            }
         }else if(TipoClave==1){
            if(Rx_Buffer[4]==0x34&&Rx_Buffer[5]==0x34&&Rx_Buffer[6]==0x34&&Rx_Buffer[7]==0x34){ // Si Ingresa clave de Servicio Tecnico
               UART_2_PutString("page Config");
               SendDataDisplay();
            }else{
               UART_2_PutString("page Principal");
               SendDataDisplay();
            }
         }else if(TipoClave==2){
            if(Rx_Buffer[4]>=0x30 && Rx_Buffer[5]>=0x30 && Rx_Buffer[6]>=0x30 && Rx_Buffer[7]>=0x30
            && Rx_Buffer[4]<=0x39 && Rx_Buffer[5]<=0x39 && Rx_Buffer[6]<=0x39 && Rx_Buffer[7]<=0x39){
            if((Rx_Buffer[4]==Password[0]+0x30)&&(Rx_Buffer[5]==Password[1]+0x30)&&(Rx_Buffer[6]==Password[2]+0x30)&&(Rx_Buffer[7]==Password[3]+0x30)){
               UART_2_PutString("page Clave");
               SendDataDisplay();
               UART_2_PutString("titulo.txt=\"Clave Nueva\"");
               SendDataDisplay();
               TipoClave=3;
               Rx_Buffer[3]=0x00;
               Rx_Buffer2[3]=0x00;
            }else{
               UART_2_PutString("page Principal");
               SendDataDisplay();
               //RX_Buffer[3]=0x00;
               //RX_Buffer2[3]=0x00;
            } 
            }
         }else if(TipoClave==3){
            UART_2_PutString("titulo.txt=\"Clave Nueva\"");
            SendDataDisplay();
            UART_2_PutString("page Principal");
            SendDataDisplay();
            if(!GuardaEEPROM){
               //write_eeprom(10,Rx_Buffer[4]-0x30);delay_ms(20);write_eeprom(11,Rx_Buffer[5]-0x30);delay_ms(20);
               EEPROM_WriteByte(Rx_Buffer[4]-0x30,0);CyDelay(20);
               EEPROM_WriteByte(Rx_Buffer[5]-0x30,1);CyDelay(20);
               EEPROM_WriteByte(Rx_Buffer[6]-0x30,2);CyDelay(20);
               EEPROM_WriteByte(Rx_Buffer[7]-0x30,3);CyDelay(20);
               GuardaEEPROM=ON;
            }
            Password[0]=Rx_Buffer[4]-0x30;Password[1]=Rx_Buffer[5]-0x30;Password[2]=Rx_Buffer[6]-0x30;Password[3]=Rx_Buffer[7]-0x30;
            //RX_Buffer[3]=0x00;
            //RX_Buffer2[3]=0x00;
         }else if(TipoClave==4){
            if(Rx_Buffer[4]==0x34&&Rx_Buffer[5]==0x34&&Rx_Buffer[6]==0x34&&Rx_Buffer[7]==0x34){ // Si Ingresa clave de Servicio Tecnico
               UART_2_PutString("page Test");
               SendDataDisplay();
            }else{
               UART_2_PutString("page Principal");
               SendDataDisplay();
            }
            //RX_Buffer[3]=0x00;
            //RX_Buffer2[3]=0x00;
         }
      }
    }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------       

//_--------------------------------------------------------------------------------------------------------------------------------------------------------
    if(Menu==2){ //Menu de Tiempo de Duraciòn
        
            if(Rx_Buffer[4]==0x0a){//Selecciono Minutos
               Minutos=OFF;
               Horas=ON;
            }
            
            if(Rx_Buffer[4]==0x0b){//Selecciono Segundos
               Minutos=ON;
               Horas=OFF;
            }           
            
            if(Rx_Buffer[4]==0x11){//Selecciono Regresar
               CyDelay(200);
               if(Rx_Buffer[4]==0x11){
                  Minutos=OFF;
                  Horas=OFF;
                  UART_2_PutString("page Rampas");
                  SendDataDisplay();  
                  if(!GuardaEEPROM){
                     EEPROM_WriteByte((int8)rampas[CicloLibre-1].Horas,103+((CicloLibre-1)*5));
                     CyDelay(10);
                     EEPROM_WriteByte((int8)rampas[CicloLibre-1].Minutos,104+((CicloLibre-1)*5));
                     CyDelay(10);
                     GuardaEEPROM=ON;
                  }
               }
            }
            
            
            if(Rx_Buffer[4]==0x0d){//Tecla arriba Oprimida
               if(Minutos){
                  rampas[CicloLibre-1].Minutos+=1.0;
               }
               if(Horas){
                  rampas[CicloLibre-1].Horas+=1.0;
               }  
               Rx_Buffer[4]=0x00;  
               Rx_Buffer2[4]=0x00;
            }
            
            if(Rx_Buffer[4]==0x0c){//Tecla abajo oprimida
               if(Minutos && rampas[CicloLibre-1].Minutos>0){
                  rampas[CicloLibre-1].Minutos-=1.0;
               }
               if(Horas  && rampas[CicloLibre-1].Horas>0){
                  rampas[CicloLibre-1].Horas-=1.0;
               }
               Rx_Buffer[4]=0x00;  
               Rx_Buffer2[4]=0x00;
            }
            
            if(rampas[CicloLibre-1].Horas>99)rampas[CicloLibre-1].Horas=1;
            if(rampas[CicloLibre-1].Minutos>59)rampas[CicloLibre-1].Minutos=0;
               
            sprintf(displayStr,"tminsec.txt=\"%02u\"",rampas[CicloLibre-1].Horas);
            UART_2_PutString(displayStr);
            SendDataDisplay();
            sprintf(displayStr,"tsecsec.txt=\"%02u\"",rampas[CicloLibre-1].Minutos);
            UART_2_PutString(displayStr);
            SendDataDisplay();
         
    }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------       

//_--------------------------------------------------------------------------------------------------------------------------------------------------------
    if(Menu==3){ //Menu de Temperatura
      
         if(rampas[CicloLibre-1].Temperatura<10)
            rampas[CicloLibre-1].Temperatura=1200;
         if(rampas[CicloLibre-1].Temperatura>1200)
            rampas[CicloLibre-1].Temperatura=10;
         
         if(Rx_Buffer[4]==0x11){//Selecciono Regresar
            Horas=OFF;
            Minutos=OFF;
            UART_2_PutString("page Rampas");
            SendDataDisplay();  
            if(!GuardaEEPROM){
               EEPROM_WriteByte((int8)rampas[CicloLibre-1].Temperatura,100+((CicloLibre-1)*5));
               EEPROM_WriteByte(convert8(rampas[CicloLibre-1].Temperatura,1),101+((CicloLibre-1)*5));
               CyDelay(10);
               GuardaEEPROM=ON;
            }
         }
         
         if(Rx_Buffer[4]==0x0d){//Tecla Arriba Oprimida
            rampas[CicloLibre-1].Temperatura+=1;
            Rx_Buffer[4]=0x00;  
            Rx_Buffer2[4]=0x00;            
         }
         
         if(Rx_Buffer[4]==0x0c){//Tecla Abajo Oprimida
            rampas[CicloLibre-1].Temperatura-=1;
            Rx_Buffer[4]=0x00;
            Rx_Buffer2[4]=0x00;                        
         }
         sprintf(displayStr,"tsettem.txt=\"%04u\"",rampas[CicloLibre-1].Temperatura);
         UART_2_PutString(displayStr);
         SendDataDisplay();
      
    }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------       

//_--------------------------------------------------------------------------------------------------------------------------------------------------------
   if(Menu==8){ //Menu de Rampas
      
      for(i=0;i<10;i++){
         if(rampas[i].Horas==0 && rampas[i].Minutos==0){
            Segmentos=i;  
            break;
         }else{
            Segmentos=i+1;  
         }
      }
      
      sprintf(displayStr,"t0.txt=\"Pasos Programados %02u; Paso: %02u\"",Segmentos,CicloLibre);
      UART_2_PutString(displayStr);
      SendDataDisplay();
      GuardaEEPROM=OFF;
      
      if(Rx_Buffer[4]>0x00 && Rx_Buffer[4]<21){//Personalizados
         if(CicloLibre>1){
            sprintf(displayStr,"t2.txt=\"TA:%04u°C\"",rampas[CicloLibre-2].Temperatura);
            UART_2_PutString(displayStr); 
            SendDataDisplay();
        }else{
            sprintf(displayStr,"t2.txt=\"TA:---\"");
            UART_2_PutString(displayStr); 
            SendDataDisplay();
        }
         sprintf(displayStr,"temp.txt=\"T:%04u°C\"",rampas[Rx_Buffer[4]-1].Temperatura);
         UART_2_PutString(displayStr); 
         SendDataDisplay();
         sprintf(displayStr,"tiempo.txt=\"%02u:%02u \"",rampas[Rx_Buffer[4]-1].Horas,rampas[Rx_Buffer[4]-1].Minutos);
         UART_2_PutString(displayStr); 
         SendDataDisplay();
         CicloLibre=Rx_Buffer[4];
      }else if(CicloLibre==0x00){
         sprintf(displayStr,"t2.txt=\"TA:---\"");
         UART_2_PutString(displayStr); 
         SendDataDisplay();
         sprintf(displayStr,"temp.txt=\"T: --\"");
        UART_2_PutString(displayStr); 
         SendDataDisplay();
         sprintf(displayStr,"tiempo.txt=\"--:--\"");
        UART_2_PutString(displayStr); 
         SendDataDisplay();
      }else if(CicloLibre>0 && CicloLibre<21){
        if(CicloLibre>1){
            sprintf(displayStr,"t2.txt=\"TA:%04u°C\"",rampas[CicloLibre-2].Temperatura);
            UART_2_PutString(displayStr); 
            SendDataDisplay();
        }else{
            sprintf(displayStr,"t2.txt=\"TA:---\"");
            UART_2_PutString(displayStr); 
            SendDataDisplay();
        }
        sprintf(displayStr,"temp.txt=\"T:%04u°C\"",rampas[CicloLibre-1].Temperatura);
        UART_2_PutString(displayStr); 
         SendDataDisplay();
         sprintf(displayStr,"tiempo.txt=\"%02u:%02u \"",rampas[CicloLibre-1].Horas,rampas[CicloLibre-1].Minutos);
        UART_2_PutString(displayStr); 
         SendDataDisplay();
      }
      
      if(Rx_Buffer[4]==0x20 && CicloLibre>0){//20, Temperatura
         UART_2_PutString("page Temperatura");
         SendDataDisplay();     
         rampa=ON;
      }
      
      if(Rx_Buffer[4]==0x40 && CicloLibre>0){//40, Tiempo
         UART_2_PutString("page Tiempo");
         SendDataDisplay();     
         rampa=ON;
      }
      
      if(Rx_Buffer[4]==0x70){//70, Regresar
         //UART_2_PutString("page Principal");
         //SendDataDisplay();     
         rampa=OFF;
      }
   }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------       
        
//_--------------------------------------------------------------------------------------------------------------------------------------------------------      
    if(Menu==15){//Menu de Clave Correcta
      if(!entro){
         CyDelay(2000);
         entro=ON;
      }
      UART_2_PutString("page Rampas");
      SendDataDisplay();
   }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------      

//_--------------------------------------------------------------------------------------------------------------------------------------------------------      
    if(Menu==16){//Menu de Clave InCorrecta
      if(!entro){
         CyDelay(2000);
         entro=ON;
      }
      UART_2_PutString("page Clave");
      SendDataDisplay();
   }
//_--------------------------------------------------------------------------------------------------------------------------------------------------------      

            
        ADC_StartConvert();
        /*Note in this example a blocking call is used, this can be replaced
        with a polling method is required in your application*/
	    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
	    ADC_StopConvert();
	    hotJnCount = ADC_GetResult32();
		
		/* Find thermo-emf in microvolts */
	    tcHotJnuVolt = ADC_CountsTo_uVolts(hotJnCount);
		
		/* Convert thermo-emf to temperature */
	    tcTemp = Thermocouple_1_GetTemperature(tcHotJnuVolt+798);
	    
		/* If thermocouple is broken, display broken alert, else display thermocouple temperature */
		if (tcHotJnuVolt < BROKEN_TC_THRESHOLD)
		{
			LCD_Char_1_Position(2,5);
			LCD_Char_1_PrintString("Broken");
			first = 1;
		}
	    else
		{
			if (first)
			{
			    LCD_Char_1_Position(2, 5);
				LCD_Char_1_PrintString("      ");
				first = 0;
			}
			/* 50 is added to round-off the temperature so that the maximum error will be <=0.5 */		
			sprintf(displayStr, "%ld  ", ((tcTemp+50)/100));		
		    LCD_Char_1_Position(2, 5);
			LCD_Char_1_PrintString(displayStr); 
		}
		
		/* Display cold junction temperature */
		/* 50 is added to round-off the temperature so that the maximum error will be <=0.5 */
		sprintf(displayStr, "%06ld   ", hotJnCount);
	    LCD_Char_1_Position(3, 5);
		LCD_Char_1_PrintString(displayStr);
		
		/* Display which sensor was used for CJC */
        /* This is controlled by SW2*/
		
		sprintf(displayStr, "%06ld   ", tcHotJnuVolt);
	    LCD_Char_1_Position(1, 9);
		LCD_Char_1_PrintString(displayStr);
		
        
        if(0u == CapSense_IsBusy())
        {
            /* Update all baselines */
            CapSense_UpdateEnabledBaselines();

            /* Start scanning all enabled sensors */
            CapSense_ScanEnabledWidgets();
        }

        //USBUART_PutCRLF();
        //USBUART_PutChar(i);
        
        PWM_WriteCompare1(pwm1);
        PWM_WriteCompare2(pwm2);
        
        LCD_Char_1_Position(3u,15u);
        LCD_Char_1_PrintInt8(i);  
        
        //LCD_Char_1_Position(2u,5u);
        //LCD_Char_1_PrintInt8(pwm1);  
        
        //LCD_Char_1_Position(3u,5u);
        //LCD_Char_1_PrintInt8(pwm2);  
        //LCD_Char_1_Print
        //LCD_Char_1_DrawHorizontalBG(1u,0u,20,i);
        CyDelay(100);
     }
}

void CapSense_DisplayState(void)
{    
    /* Display BUTTON0 state */
    if (CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN)){
        pwm1++;
        flagButton0=1;
    }else{
        flagButton0=0;   
    }
    if (CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN) && !flagButton1){
        pwm1--;
        flagButton1=1;
    }else{
        flagButton1=0;   
    }
    
    if (CapSense_CheckIsWidgetActive(CapSense_BUTTON2__BTN) && !flagButton2){
        pwm2++;
        flagButton2=1;
    }else{
        flagButton2=0;   
    }
    if (CapSense_CheckIsWidgetActive(CapSense_BUTTON3__BTN) && !flagButton3){
        pwm2--;
        flagButton3=1;
    }else{
        flagButton3=0;   
    }
}
/* [] END OF FILE */
