/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
#include <stdio.h>
#include <main.h>
#include "project.h"

short PidePassword(uint8 MenuAnt, uint8 MenuActual, uint8 MenuPost, uint8 clave0,uint8 clave1, uint8 clave2,uint8 clave3);
void MuestraSegmento(uint8 Opcio,uint8 l,uint8 Prog );

/* [] END OF FILE */
