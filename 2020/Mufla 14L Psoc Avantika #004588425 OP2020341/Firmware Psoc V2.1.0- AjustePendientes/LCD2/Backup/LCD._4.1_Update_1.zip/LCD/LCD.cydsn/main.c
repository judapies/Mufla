/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

extern uint8 const CYCODE LCD_customFonts[];  

int main(void)
{
    int32 output,decimal=0,Entero=0,IntV=0,DecV=0;
    float ADCVoltaje,Pt=0.0,Pt_dec=0,DecVV=0;
    float a=0.0011,b=2.3302,c=-244.0723,Temperatura=0;
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    LCD_Char_1_Start();  
  
    LCD_Char_1_Position(0u, 0u); // first row, first position  
    LCD_Char_1_PrintString("Dielec Ingenieria");  
  
    LCD_Char_1_Position(1u, 0u); // second row, ninth position  
    LCD_Char_1_PrintString("Lectura de PT100");  
    
    LCD_Char_1_Position(2u, 0u); // second row, ninth position  
    LCD_Char_1_PrintString("Resistencia:");  
    
    /* Starts PGA component */
    PGA_1_Start();
    
    /* Sets the PGA gain to 1 */
    PGA_1_SetGain(PGA_1_GAIN_24);
    
    /* Sets the power mode to medium power */
    PGA_1_SetPower(PGA_1_MEDPOWER);
    
    ADC_Start();
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
   
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        
        output=ADC_GetResult32(); // Lectura del ADC
        ADCVoltaje=(5.0000/1048576.0000)*output; //Calculo del voltaje de entrada del ADC
        output=output/24; // Se elimina el valor de Ganancia del amplificador
        Pt=(5500.0)/((1048576.0/output)-1.0); // Calculo de el valor en ohm de PT100
        Pt=Pt-4.3;
        //Division de parte entera y decimal de Pt100
        Entero=(int8)Pt;
        Pt_dec=(Pt-Entero);
        Pt_dec=Pt_dec*10;
        decimal=Pt_dec;
        
        //Division de parte entera y decimal de Voltaje
        IntV=(int8)ADCVoltaje;
        DecVV=ADCVoltaje-IntV;
        DecVV=DecVV*10;
        DecV=DecVV;
        
        Temperatura=((Pt*Pt)*a)+(Pt*b)+c; 
        
        if(ADCVoltaje>2.5){
            LED_Write(1);
        }else{
            LED_Write(0);
        } 
        
        LCD_Char_1_Position(3u,0u); 
        LCD_Char_1_PrintString("T:");  
        LCD_Char_1_Position(3u,2u);
        LCD_Char_1_PrintNumber(Temperatura);
        LCD_Char_1_Position(3u,4u); 
        LCD_Char_1_PrintString(".");  
        LCD_Char_1_Position(3u,5u);
        LCD_Char_1_PrintNumber((Temperatura-(int8)Temperatura)*100);
        
        LCD_Char_1_Position(3u,8u); 
        LCD_Char_1_PrintString("V:");  
        LCD_Char_1_Position(3u,10u);
        LCD_Char_1_PrintNumber(IntV);
        LCD_Char_1_Position(3u,11u); 
        LCD_Char_1_PrintString(".");  
        LCD_Char_1_Position(3u,12u);
        LCD_Char_1_PrintNumber(DecV);
        
        LCD_Char_1_Position(2u,12u);
        LCD_Char_1_PrintNumber(Pt);  
        LCD_Char_1_Position(2u,15u); 
        LCD_Char_1_PrintString(".");  
        LCD_Char_1_Position(2u,16u);
        LCD_Char_1_PrintNumber(decimal);  
        
        CyDelay(500);
     }
}

/* [] END OF FILE */
